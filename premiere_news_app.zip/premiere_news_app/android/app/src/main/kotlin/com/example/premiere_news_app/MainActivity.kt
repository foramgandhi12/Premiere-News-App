package com.example.premiere_news_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
